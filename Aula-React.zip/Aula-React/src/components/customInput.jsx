import React from 'react';

const CustomInput = ({ initialValue, type, placeholder }) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={initialValue}
      style={{ color: 'red' }}
    />
  );
};

export default CustomInput;

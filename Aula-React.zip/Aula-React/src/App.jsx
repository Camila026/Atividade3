import React from 'react';
import CustomInput from './CustomInput';

function App() {
  return (
    <div>
      <form>
        <div>
          <label htmlFor="nome">Nome:</label>
          <CustomInput
            type="text"
            placeholder="Digite seu nome"
            initialValue=""
          />
        </div>
        <div>
          <label htmlFor="email">E-mail:</label>
          <CustomInput
            type="email"
            placeholder="Digite seu e-mail"
            initialValue=""
          />
        </div>
        <div>
          <label htmlFor="telefone">Telefone:</label>
          <CustomInput
            type="tel"
            placeholder="Digite seu telefone"
            initialValue=""
          />
        </div>
        <div>
          <button type="submit">Enviar</button>
        </div>
      </form>
    </div>
  );
}

export default App;
